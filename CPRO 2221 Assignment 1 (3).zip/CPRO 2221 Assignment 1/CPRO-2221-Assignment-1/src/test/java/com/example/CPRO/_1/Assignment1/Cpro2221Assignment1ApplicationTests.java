package com.example.CPRO._1.Assignment1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cpro2221Assignment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
