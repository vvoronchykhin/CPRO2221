package com.example.productapp.entity;

import jakarta.persistence.*;
import lombok.*;
import java.sql.Timestamp;

@Entity // JPA entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment primary key
    private Long id;

    @Column(nullable = false) // Non-nullable column
    private String name;

    @Column(length = 500) // Max length: 500 characters
    private String description;

    private double price; // Consider BigDecimal for precision
    private int quantity;

    @Column(name = "created_at", updatable = false) // Immutable after creation
    private Timestamp createdAt;

    @PrePersist // Sets createdAt before saving
    protected void onCreate() {
        createdAt = new Timestamp(System.currentTimeMillis());
    }
}
