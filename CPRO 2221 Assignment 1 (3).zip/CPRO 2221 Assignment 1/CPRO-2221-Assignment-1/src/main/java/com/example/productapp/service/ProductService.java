package com.example.productapp.service;

import com.example.productapp.entity.Product;
import com.example.productapp.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service // Marks this class as a Spring service
public class ProductService {

    @Autowired // Injects the ProductRepository
    private ProductRepository productRepository;

    public List<Product> getAllProducts() {
        return productRepository.findAll(); // Retrieves all products
    }

    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id); // Retrieves a product by its ID
    }

    public Product createProduct(Product product) {
        return productRepository.save(product); // Saves a new product
    }

    public Product updateProduct(Long id, Product product) {
        Optional<Product> existingProduct = productRepository.findById(id);
        if (existingProduct.isPresent()) {
            Product updatedProduct = existingProduct.get();
            updatedProduct.setName(product.getName());
            updatedProduct.setDescription(product.getDescription());
            updatedProduct.setPrice(product.getPrice());
            updatedProduct.setQuantity(product.getQuantity());
            return productRepository.save(updatedProduct); // Updates the product
        }
        return null; // Returns null if the product doesn't exist
    }

    public void deleteProduct(Long id) {
        productRepository.deleteById(id); // Deletes a product by its ID
    }
}
