package com.example.productapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment1Application {

    public static void main(String[] args) {
        SpringApplication.run(Assignment1Application.class, args);
        System.out.println("Database URL: " + System.getenv("SPRING_DATASOURCE_URL"));
        SpringApplication.run(Assignment1Application.class, args);
    }

}