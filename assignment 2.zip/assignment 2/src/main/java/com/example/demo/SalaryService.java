package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public class SalaryService {
    public double calculateSalary(String designation) {
        switch (designation) {
            case "Manager":
                return 80000.0;
            case "Developer":
                return 60000.0;
            case "Analyst":
                return 50000.0;
            case "Tester":
                return 40000.0;
            default:
                return 0.0;
        }
    }
}
