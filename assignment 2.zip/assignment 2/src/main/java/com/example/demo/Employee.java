package com.example.demo;

import jakarta.validation.constraints.NotEmpty;
import java.util.List;

public class Employee {
    @NotEmpty(message = "Name is required.")
    private String name;

    @NotEmpty(message = "Designation is required.")
    private String designation;

    private double salary; // Automatically assigned

    private boolean employmentType; // Full-Time (true) or Part-Time (false)

    private List<String> departments;

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public boolean isEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(boolean employmentType) {
        this.employmentType = employmentType;
    }

    public List<String> getDepartments() {
        return departments;
    }

    public void setDepartments(List<String> departments) {
        this.departments = departments;
    }
}
