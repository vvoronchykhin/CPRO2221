package com.example.demo;

import org.springframework.stereotype.Service;
import java.util.Arrays;
import java.util.List;

@Service
public class DepartmentService {
    public List<String> getDepartments() {
        return Arrays.asList("HR", "Finance", "IT", "Operations");
    }
}

