package com.example.demo;


import com.example.demo.Employee;
import com.example.demo.SalaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.validation.Valid;
import java.util.Arrays;
import java.util.List;

@Controller
public class EmployeeController {

    @Autowired
    private SalaryService salaryService;

    @Autowired
    private DepartmentService departmentService;

    @GetMapping("/")
    public String showForm(Model model) {
        model.addAttribute("employee", new Employee());
        model.addAttribute("designations", getDesignations());
        model.addAttribute("departments", departmentService.getDepartments()); // Use the service here
        return "employeeForm";
    }


    @PostMapping("/submit")
    public String submitForm(
            @Valid @ModelAttribute("employee") Employee employee,
            BindingResult bindingResult,
            Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("designations", getDesignations());
            model.addAttribute("departments", getDepartments());
            return "employeeForm";
        }

        // Assign salary based on designation
        double salary = salaryService.calculateSalary(employee.getDesignation());
        employee.setSalary(salary);

        model.addAttribute("employee", employee);
        return "success";
    }

    private List<String> getDesignations() {
        return Arrays.asList("Manager", "Developer", "Analyst", "Tester");
    }

    private List<String> getDepartments() {
        return Arrays.asList("HR", "Finance", "IT", "Operations");
    }
}
